package uniandes.dpoo.hamburguesas.mundo;

import java.util.ArrayList;

/**
 * La clase utilizada para organizar la información de un combo.
 */
public class Combo implements Producto {

    /**
     * Los productos que hacen parte del combo.
     */
    private ArrayList<ProductoMenu> itemsCombo;

    /**
     * El descuento que incluye el combo. Es un número entre 0 y 1, donde 0 corresponde a que no hay descuento y 1 corresponde al 100% de descuento.
     */
    private double descuento;

    /**
     * El nombre del combo.
     */
    private String nombreCombo;

    /**
     * Construye un nuevo combo.
     * 
     * @param nombre El nombre del combo.
     * @param descuento El descuento sobre el valor normal de los productos en el combo.
     * @param items Los productos que hacen parte del combo.
     */
    public Combo(String nombre, double descuento, ArrayList<ProductoMenu> items) {
        this.itemsCombo = new ArrayList<>(items);
        this.nombreCombo = nombre;
        this.descuento = descuento;
    }

    /**
     * Constructor adicional para crear un combo sin productos inicialmente.
     * 
     * @param nombre El nombre del combo.
     * @param descuento El descuento sobre el valor normal de los productos en el combo.
     */
    public Combo(String nombre, double descuento) {
        this.nombreCombo = nombre;
        this.descuento = descuento;
        this.itemsCombo = new ArrayList<>(); // Inicializa con una lista vacía
    }

    @Override
    public String getNombre() {
        return nombreCombo;
    }

    /**
     * Agrega un producto al combo.
     * 
     * @param producto El producto a agregar.
     */
    public void agregarItem(ProductoMenu producto) {
        itemsCombo.add(producto);
    }

    /**
     * Retorna el precio del combo.
     * 
     * El precio está basado en aplicarle el descuento del combo al valor de cada uno de los productos.
     */
    @Override
    public int getPrecio() {
        double precioTotal = 0;
        for (Producto i : itemsCombo) {
            precioTotal += i.getPrecio();
        }
        // Aplica el descuento y redondea el resultado
        precioTotal = precioTotal * (1 - descuento);
        return (int) Math.round(precioTotal);
    }

    /**
     * Genera el texto que debe aparecer en la factura.
     * 
     * El texto incluye el nombre del combo, su costo y el valor del descuento.
     */
    @Override
    public String generarTextoFactura() {
        StringBuffer sb = new StringBuffer();
        sb.append("Combo " + nombreCombo + "\n");
        sb.append(" Descuento: " + descuento + "\n");
        sb.append("            " + getPrecio() + "\n");
        return sb.toString();
    }
}
