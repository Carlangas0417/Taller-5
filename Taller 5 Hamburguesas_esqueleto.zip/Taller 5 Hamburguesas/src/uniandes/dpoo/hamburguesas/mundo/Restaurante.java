package uniandes.dpoo.hamburguesas.mundo;

import java.io.*;
import java.util.ArrayList;
import uniandes.dpoo.hamburguesas.excepciones.*;

/**
 * La clase que administra toda la información del restaurante de hamburguesas.
 */
public class Restaurante {

    /**
     * La ruta a la carpeta donde se almacenan las facturas.
     */
    private static final String CARPETA_FACTURAS = "./facturas/";

    /**
     * La primera parte del nombre de los archivos de facturas.
     */
    private static final String PREFIJO_FACTURAS = "factura_";

    /**
     * La lista de pedidos que ha recibido el restaurante y que ya se han cerrado.
     */
    private ArrayList<Pedido> pedidos;

    /**
     * La lista de ingredientes disponibles para las hamburguesas.
     */
    private ArrayList<Ingrediente> ingredientes;

    /**
     * La lista de Items que conforman el menú de productos básicos del restaurante.
     */
    private ArrayList<ProductoMenu> menuBase;

    /**
     * La lista de Combos que ofrece el restaurante.
     */
    private ArrayList<Combo> menuCombos;

    /**
     * El pedido en curso. Cuando no hay un pedido en curso, este atributo será null.
     */
    private Pedido pedidoEnCurso;

    /**
     * Crea un restaurante vacío, sin pedidos, ingredientes, ni ítems en el menú.
     */
    public Restaurante() {
        pedidos = new ArrayList<>();
        ingredientes = new ArrayList<>();
        menuBase = new ArrayList<>();
        menuCombos = new ArrayList<>();
    }

    /**
     * Carga la información del restaurante utilizando archivos predeterminados.
     */
    public void cargarInformacionRestaurante() throws HamburguesaException, NumberFormatException, IOException {
        File archivoIngredientes = new File("./data/ingredientes.txt");
        File archivoMenu = new File("./data/menu.txt");
        File archivoCombos = new File("./data/combos.txt");
        cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
    }

    /**
     * Carga la información de los ingredientes, los productos y los combos del restaurante.
     */
    public void cargarInformacionRestaurante(File archivoIngredientes, File archivoMenu, File archivoCombos) throws HamburguesaException, NumberFormatException, IOException {
        cargarIngredientes(archivoIngredientes);
        cargarMenu(archivoMenu);
        cargarCombos(archivoCombos);
    }

    private void cargarIngredientes(File archivoIngredientes) throws IngredienteRepetidoException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader(archivoIngredientes));
        try {
            String linea = reader.readLine();
            while (linea != null) {
                if (!linea.isEmpty()) {
                    String[] ingredientesStr = linea.split(";");
                    String nombreIngrediente = ingredientesStr[0];
                    int costoIngrediente = Integer.parseInt(ingredientesStr[1]);
                    Ingrediente ingrediente = new Ingrediente(nombreIngrediente, costoIngrediente);

                    for (Ingrediente i : this.ingredientes) {
                        if (i.getNombre().equals(nombreIngrediente)) {
                            throw new IngredienteRepetidoException(nombreIngrediente);
                        }
                    }
                    this.ingredientes.add(ingrediente);
                }
                linea = reader.readLine();
            }
        } finally {
            reader.close();
        }
    }

    private void cargarMenu(File archivoMenu) throws ProductoRepetidoException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader(archivoMenu));
        try {
            String linea = reader.readLine();
            while (linea != null) {
                if (!linea.isEmpty()) {
                    String[] productoStr = linea.split(";");
                    String nombreProducto = productoStr[0];
                    int costoProducto = Integer.parseInt(productoStr[1]);
                    ProductoMenu producto = new ProductoMenu(nombreProducto, costoProducto);

                    for (ProductoMenu prod : this.menuBase) {
                        if (prod.getNombre().equals(nombreProducto)) {
                            throw new ProductoRepetidoException(nombreProducto);
                        }
                    }
                    this.menuBase.add(producto);
                }
                linea = reader.readLine();
            }
        } finally {
            reader.close();
        }
    }

    private void cargarCombos(File archivoCombos) throws ProductoRepetidoException, ProductoFaltanteException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader(archivoCombos));
        try {
            String linea = reader.readLine();
            while (linea != null) {
                if (!linea.isEmpty()) {
                    String[] comboStr = linea.split(";");
                    String nombreCombo = comboStr[0];
                    double descuento = Double.parseDouble(comboStr[1].replace("%", "")) / 100;

                    for (Combo c : this.menuCombos) {
                        if (c.getNombre().equals(nombreCombo)) {
                            throw new ProductoRepetidoException(nombreCombo);
                        }
                    }

                    ArrayList<ProductoMenu> itemsCombo = new ArrayList<>();
                    for (int i = 2; i < comboStr.length; i++) {
                        String nombreProducto = comboStr[i];
                        ProductoMenu productoItem = buscarProducto(nombreProducto);

                        if (productoItem == null) {
                            throw new ProductoFaltanteException(nombreProducto);
                        }

                        itemsCombo.add(productoItem);
                    }

                    Combo combo = new Combo(nombreCombo, descuento, itemsCombo);
                    this.menuCombos.add(combo);
                }
                linea = reader.readLine();
            }
        } finally {
            reader.close();
        }
    }

    public void iniciarPedido(String nombreCliente, String direccionCliente) throws YaHayUnPedidoEnCursoException {
        if (pedidoEnCurso != null)
            throw new YaHayUnPedidoEnCursoException(pedidoEnCurso.getNombreCliente(), nombreCliente);

        pedidoEnCurso = new Pedido(nombreCliente, direccionCliente);
    }

    public void cerrarYGuardarPedido() throws NoHayPedidoEnCursoException, IOException {
        if (pedidoEnCurso == null)
            throw new NoHayPedidoEnCursoException();

        String nombreArchivo = PREFIJO_FACTURAS + pedidoEnCurso.getIdPedido() + ".txt";
        pedidoEnCurso.guardarFactura(new File(CARPETA_FACTURAS + nombreArchivo));
        pedidos.add(pedidoEnCurso);
        pedidoEnCurso = null;
    }

    public Pedido getPedidoEnCurso() {
        return pedidoEnCurso;
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    public ArrayList<ProductoMenu> getMenuBase() {
        return menuBase;
    }

    public ArrayList<Combo> getMenuCombos() {
        return menuCombos;
    }

    public ArrayList<Ingrediente> getIngredientes() {
        return ingredientes;
    }

    public void agregarProductoMenu(ProductoMenu producto) {
        menuBase.add(producto);
    }

    public ProductoMenu buscarProducto(String nombre) {
        for (ProductoMenu producto : menuBase) {
            if (producto.getNombre().equals(nombre)) {
                return producto;
            }
        }
        return null;
    }

    public void agregarCombo(Combo combo) {
        menuCombos.add(combo);
    }

    public Combo buscarCombo(String nombre) {
        for (Combo combo : menuCombos) {
            if (combo.getNombre().equals(nombre)) {
                return combo;
            }
        }
        return null;
    }
}
