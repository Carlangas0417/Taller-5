package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.excepciones.HamburguesaException;
import java.io.IOException;

class RestauranteTest {

    private Restaurante restaurante;

    @BeforeEach
    void setUp() throws HamburguesaException, IOException {
        restaurante = new Restaurante();
        restaurante.cargarInformacionRestaurante();
    }

    @Test
    void testAgregarProducto() {
        ProductoMenu producto = new ProductoMenu("Ensalada", 5000);
        restaurante.agregarProductoMenu(producto);
        assertEquals(producto, restaurante.buscarProducto("Ensalada"));
    }

    @Test
    void testAgregarCombo() {
        Combo combo = new Combo("Combo Light", 0.05);
        restaurante.agregarCombo(combo);
        assertEquals(combo, restaurante.buscarCombo("Combo Light"));
    }
}
