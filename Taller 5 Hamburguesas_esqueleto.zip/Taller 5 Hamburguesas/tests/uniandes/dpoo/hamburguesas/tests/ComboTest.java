package uniandes.dpoo.hamburguesas.tests;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ComboTest {

    private Combo combo;

    @BeforeEach
    void setUp() {
        combo = new Combo("Combo Especial", 0.07);
        combo.agregarItem(new ProductoMenu("Hamburguesa Sencilla", 8000));
        combo.agregarItem(new ProductoMenu("Papas Medianas", 3000));
    }

    @Test
    void testGetPrecio() {
        assertEquals(10270, combo.getPrecio());
    }

    @Test
    void testGetNombre() {
        assertEquals("Combo Especial", combo.getNombre());
    }
}
