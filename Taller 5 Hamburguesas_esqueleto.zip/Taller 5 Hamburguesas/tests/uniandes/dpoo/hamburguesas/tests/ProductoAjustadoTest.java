package uniandes.dpoo.hamburguesas.tests;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;

class ProductoAjustadoTest {

    private ProductoAjustado productoAjustado;
    private Ingrediente queso;

    @BeforeEach
    void setUp() {
        ProductoMenu base = new ProductoMenu("Hamburguesa Sencilla", 8000);
        productoAjustado = new ProductoAjustado(base);
        queso = new Ingrediente("Queso", 1000);
    }

    @Test
    void testAgregarIngrediente() {
        productoAjustado.agregarIngrediente(queso);
        assertEquals(9000, productoAjustado.getPrecio());
    }

    @Test
    void testQuitarIngrediente() {
        productoAjustado.quitarIngrediente(queso);
        assertEquals(8000, productoAjustado.getPrecio());
    }
}
