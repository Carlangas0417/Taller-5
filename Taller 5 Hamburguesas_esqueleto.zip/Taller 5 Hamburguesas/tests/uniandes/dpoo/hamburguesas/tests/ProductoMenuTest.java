package uniandes.dpoo.hamburguesas.tests;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ProductoMenuTest {

    private ProductoMenu productoMenu;

    @BeforeEach
    void setUp() {
        productoMenu = new ProductoMenu("Hamburguesa Sencilla", 8000);
    }

    @Test
    void testGetNombre() {
        assertEquals("Hamburguesa Sencilla", productoMenu.getNombre());
    }

    @Test
    void testGetPrecio() {
        assertEquals(8000, productoMenu.getPrecio());
    }

    @Test
    void testToString() {
        assertTrue(productoMenu.toString().contains("Hamburguesa Sencilla"));
    }
}
